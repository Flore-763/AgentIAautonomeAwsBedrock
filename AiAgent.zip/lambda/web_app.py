"""
lambda/web_app.py
==================
Point d'entrée HTTP (FastAPI) exécuté derrière AWS Lambda Web Adapter.
Remplace agent_handler.py comme point d'entrée du conteneur.
"""
import json
from fastapi import FastAPI
from fastapi.responses import StreamingResponse, JSONResponse
from langchain_core.messages import HumanMessage

from graph.workflow import get_graph
from services.agent_service import process_chat_message  # inchangé, réutilisé tel quel
from services.memory_service import memory_service
from services.bedrock_service import invoke_titan_embedding
from services.memory_service import get_chat_history
from services.prompt_service import format_memories_block
from vector_store import vector_store
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from langchain_core.messages import AIMessageChunk

def _decimal_to_native(obj):
    if isinstance(obj,list):
        return [_decimal_to_native(x) for x in obj]
    if isinstance(obj,dict):
        return {k:_decimal_to_native(v) for k,v in obj.items()}
    if isinstance(obj,Decimal):
        return int(obj) if obj % 1 == 0 else float(obj)
    return obj


def _extract_text(content) -> str:
    """
    ChatBedrockConverse peut renvoyer .content comme :
      - une string simple, OU
      - une liste de blocs (ex: [{"type": "text", "text": "..."}])
    On normalise toujours vers une string.
    """
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        text = ""
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                text += block.get("text", "")
            elif isinstance(block, str):
                text += block
        return text
    return ""

app = FastAPI()




@app.get("/health")
def health():
    # utilisé par AWS_LWA_READINESS_CHECK_PATH
    return {"status": "ok"}


@app.post("/agent/chat")
def chat(payload: dict):
    # Route non-streaming : comportement identique à agent_handler.py aujourd'hui
    result = process_chat_message(
        message=payload["message"].strip(),
        session_id=payload.get("session_id"),
        max_iterations=payload.get("max_iterations", 10),
    )
    return JSONResponse(result)


@app.get("/agent/sessions/{session_id}/history")
def history(session_id: str):
    hist = memory_service.get_conversation_history(session_id)
    data= memory_service.format_history_response(session_id, hist)
    return JSONResponse(_decimal_to_native(data))


def sse_event(event_type: str, data) -> str:
    """Formate une ligne SSE valide."""
    payload = json.dumps({"type": event_type, "data": data}, ensure_ascii=False)
    return f"data: {payload}\n\n"


@app.post("/agent/chat/stream")
def chat_stream(payload: dict):
    message = payload["message"].strip()
    session_id = payload.get("session_id") or str(uuid.uuid4())
    max_iterations = min(payload.get("max_iterations", 10), 20)

    def event_generator():
        # même logique de contexte que process_chat_message
        chat_history = get_chat_history(session_id, window_size=5)
        message_embedding = invoke_titan_embedding(message)
        semantic_memories = vector_store.semantic_search(
            embedding=message_embedding, session_id=session_id,
            before_timestamp=chat_history.oldest_timestamp, k=3,
        )
        context = format_memories_block(semantic_memories)

        graph = get_graph()
        initial_state = {
            "session_id": session_id,
            "messages": chat_history.messages + [HumanMessage(content=message)],
            "context": context, "iterations": 0,
            "max_iterations": max_iterations,
            "tool_call_history": [], "final_answer": None, "error": None,
        }
        config = {"configurable": {"thread_id": session_id}}

        yield sse_event("session", {"session_id": session_id})

        current_segment = ""
        full_answer = ""

        for mode, chunk in graph.stream(initial_state, config=config,
                                        stream_mode=["messages", "updates"]):
            if mode == "messages":
                token_chunk, _meta = chunk
                if not isinstance(token_chunk, AIMessageChunk):
                    continue
                text = _extract_text(getattr(token_chunk, "content", None))
                if text:
                    current_segment += text
                    yield sse_event("token", text)   # toujours streamé en direct
            elif mode == "updates":
                for node_name in chunk:
                    yield sse_event("step", {"node": node_name})
                    if node_name == "call_model":
                        # une nouvelle itération de réflexion démarre :
                        # on "oublie" le segment précédent (c'était du texte
                        # d'annonce avant un appel d'outil, pas la réponse finale)
                        full_answer = current_segment
                        current_segment = ""
        # sauvegarde finale (comme process_chat_message le fait déjà)
        response_embedding = invoke_titan_embedding(full_answer)
        memory_service.batch_save_turn(
            session_id=session_id, user_message=message,
            assistant_response=full_answer,
            user_embedding=message_embedding, response_embedding=response_embedding,
        )
        yield sse_event("done", {"final_answer": full_answer})

    return StreamingResponse(event_generator(), media_type="text/event-stream")