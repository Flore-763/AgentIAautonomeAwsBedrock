import time

from langchain_core.tools import tool

from services.bedrock_service import invoke_titan_embedding
from services.document_index_service import document_session_id
from opensearch_config import opensearch


INDEX_NAME = "document-memory"

# OpenSearch Serverless (AOSS) rafraîchit l'index inversé (term/agg) quasi
# immédiatement, mais le graphe HNSW utilisé par les requêtes `knn` peut
# mettre quelques secondes de plus à intégrer les vecteurs tout juste
# écrits (encore plus vrai juste après la création d'un nouvel index).
# On retente donc quelques fois avant de conclure à une absence réelle
# de résultat.
_KNN_RETRY_ATTEMPTS = 5
_KNN_RETRY_DELAY_SECONDS = 2.0


def search_user_documents(
    query: str,
    user_sub: str,
    session_id: str,
) -> str:
    """
    Fonction interne exécutée par le backend.

    user_sub et session_id proviennent du JWT / state
    et ne sont jamais fournis par le LLM.
    """

    try:

        if not query.strip():
            return "La requête documentaire est vide."

        embedding = invoke_titan_embedding(query)

        if not embedding:
            return (
                "Impossible de calculer l'embedding "
                "de la requête."
            )

        indexed_session_id = document_session_id(
            user_sub,
            session_id,
        )
        print(f"🔎 SEARCH: user_sub={user_sub!r} session_id={session_id!r} -> indexed_session_id={indexed_session_id!r}")

        search_query = {
            "size": 5,
            "query": {
                "knn": {
                    "embedding": {
                        "vector": embedding,
                        "k": 5,
                        "filter": {
                            "bool": {
                                "must": [
                                    {
                                        "term": {
                                            "session_id": indexed_session_id
                                        }
                                    },
                                    {
                                        "term": {
                                            "record_type": "user_document"
                                        }
                                    }
                                ]
                            }
                        }
                    }
                }
            }
        }

        hits = []

        for attempt in range(1, _KNN_RETRY_ATTEMPTS + 1):

            response = opensearch.search(
                index=INDEX_NAME,
                body=search_query,
            )

            hits = response.get(
                "hits",
                {}
            ).get(
                "hits",
                []
            )

            if hits:
                break

            print(
                f"🔎 SEARCH: 0 hit (tentative {attempt}/{_KNN_RETRY_ATTEMPTS}) "
                f"pour indexed_session_id={indexed_session_id!r} "
                "-> nouvelle tentative (latence d'indexation KNN AOSS possible)"
            )

            if attempt < _KNN_RETRY_ATTEMPTS:
                time.sleep(_KNN_RETRY_DELAY_SECONDS)

        if not hits:
            # Dernier filet de sécurité : si le fichier est bien listé
            # (visible via l'index inversé, qui se rafraîchit plus vite
            # que le graphe KNN), on renvoie ses premiers chunks sans
            # ranking sémantique plutôt que de prétendre qu'il n'existe
            # pas de fichier du tout.
            fallback_hits = _term_only_fallback(indexed_session_id)

            if fallback_hits:
                print(
                    f"🔎 SEARCH: fallback term-only utilisé "
                    f"({len(fallback_hits)} chunk(s)) pour "
                    f"indexed_session_id={indexed_session_id!r}"
                )
                hits = fallback_hits
            else:
                return (
                    "Aucun résultat trouvé dans l'index documentaire pour "
                    "l'instant. Si un fichier vient d'être joint à ce "
                    "message, il est probablement toujours en cours "
                    "d'indexation (cela peut prendre jusqu'à quelques "
                    "dizaines de secondes juste après un chargement) : "
                    "ne pas affirmer qu'aucun fichier n'a été fourni, "
                    "informer plutôt l'utilisateur que le traitement est "
                    "en cours et proposer de réessayer sa question dans "
                    "un instant. Si en revanche aucun fichier n'a jamais "
                    "été chargé dans cette conversation, l'indiquer "
                    "normalement."
                )

        print(f"🔎 SEARCH: {len(hits)} hit(s) trouvé(s) pour indexed_session_id={indexed_session_id!r}")
        results = []

        for number, hit in enumerate(
            hits,
            start=1,
        ):

            source = hit.get(
                "_source",
                {}
            )

            filename = source.get(
                "filename",
                "fichier inconnu",
            )

            chunk_id = source.get(
                "chunk_id",
                "?",
            )

            content = source.get(
                "content",
                "",
            )

            score = hit.get(
                "_score",
                0,
            )

            results.append(
                f"[{number}] "
                f"Fichier: {filename} | "
                f"Chunk: {chunk_id} | "
                f"Pertinence: {score:.3f}\n"
                f"{content}"
            )

        return "\n\n---\n\n".join(results)

    except Exception as error:

        return (
            "Erreur pendant la recherche dans les "
            f"documents : {error}"
        )


def _term_only_fallback(indexed_session_id: str, size: int = 5) -> list:
    """
    Repli sans embedding : simple filtre `term` (session_id + record_type),
    trié par chunk_id. Utilisé uniquement si la recherche KNN n'a rien
    trouvé après plusieurs tentatives alors que le document est bien
    indexé (cf. latence du graphe HNSW sur AOSS).
    """

    fallback_query = {
        "size": size,
        "query": {
            "bool": {
                "must": [
                    {"term": {"session_id": indexed_session_id}},
                    {"term": {"record_type": "user_document"}},
                ]
            }
        },
        "sort": [{"chunk_id": "asc"}],
    }

    try:
        response = opensearch.search(
            index=INDEX_NAME,
            body=fallback_query,
        )
        return response.get("hits", {}).get("hits", [])
    except Exception as error:
        print(f"⚠️ Fallback term-only en échec : {error}")
        return []


@tool
def document_search(query: str) -> str:
    """
    Recherche dans les fichiers chargés par l'utilisateur.

    Utiliser cet outil lorsque la demande nécessite
    d'analyser, comparer, résumer ou extraire des
    informations provenant des fichiers uploadés.

    Les fichiers peuvent être des PDF, DOCX, XLSX,
    CSV, TXT, Python, Markdown ou JSON.

    Le contexte utilisateur et le session_id sont
    gérés automatiquement par le backend.
    """

    # Cette fonction ne devrait normalement jamais
    # être appelée directement par le backend,
    # car call_tools() injecte le contexte sécurisé.
    return (
        "Erreur interne : document_search doit être "
        "exécuté avec le contexte utilisateur."
    )