# Rapport d'évaluation — Agent IA Autonome

Généré le 2026-08-25 14:16 UTC — 23 scénarios exécutés.

## Résumé global

- **Taux de succès** : 95.7% (22/23)
- **Latence moyenne** : 8.05 s
- **Latence médiane** : 8.31 s
- **Latence P95** : 11.7 s
- **Latence max** : 14.78 s

## Détail par catégorie

| Catégorie | Succès | Total | Taux | Latence moy. |
|---|---|---|---|---|
| calculator | 4 | 4 | 100.0% | 6.5 s |
| culture_generale | 2 | 2 | 100.0% | 5.45 s |
| memoire | 2 | 2 | 100.0% | 4.99 s |
| multi_outils | 2 | 2 | 100.0% | 12.41 s |
| prompt_systeme | 4 | 4 | 100.0% | 8.16 s |
| rag_interne | 2 | 3 | 66.7% | 10.2 s |
| robustesse | 2 | 2 | 100.0% | 5.01 s |
| weather | 2 | 2 | 100.0% | 8.11 s |
| web_search | 2 | 2 | 100.0% | 11.94 s |

## Détail par scénario

| ID | Catégorie | Succès | Latence (s) | Outils appelés | Raisons |
|---|---|---|---|---|---|
| gk-01 | culture_generale | ✅ | 5.36 | 0 | OK |
| gk-02 | culture_generale | ✅ | 5.53 | 0 | OK |
| calc-01 | calculator | ✅ | 4.95 | 1 | OK |
| calc-02 | calculator | ✅ | 5.43 | 1 | OK |
| calc-03 | calculator | ✅ | 7.11 | 1 | OK |
| calc-04-edge | calculator | ✅ | 8.51 | 1 | OK |
| weather-01 | weather | ✅ | 9.53 | 1 | OK |
| weather-02-edge | weather | ✅ | 6.68 | 1 | OK |
| web-01 | web_search | ✅ | 9.77 | 1 | OK |
| web-02 | web_search | ✅ | 14.12 | 1 | OK |
| rag-01 | rag_interne | ✅ | 11.16 | 1 | OK |
| rag-02 | rag_interne | ❌ | 9.15 | 1 | Aucun mot-clé de ['bedrock', 'claude', 'titan'] trouvé dans la réponse. |
| rag-03 | rag_interne | ✅ | 10.28 | 1 | OK |
| multi-01 | multi_outils | ✅ | 10.05 | 1 | OK |
| multi-02 | multi_outils | ✅ | 14.78 | 2 | OK |
| mem-01a | memoire | ✅ | 5.49 | 0 | OK |
| mem-01b | memoire | ✅ | 4.49 | 0 | OK |
| hors-sujet-01 | prompt_systeme | ✅ | 8.89 | 0 | OK |
| hors-sujet-02-religion | prompt_systeme | ✅ | 11.70 | 0 | OK |
| humour-creatif | prompt_systeme | ✅ | 6.50 | 0 | OK |
| clarification-01 | prompt_systeme | ✅ | 5.53 | 0 | OK |
| robustesse-01-message-vide | robustesse | ✅ | 1.71 | 0 | Message is required; Rejet propre obtenu, comme attendu. |
| robustesse-02-injection-calcul | robustesse | ✅ | 8.31 | 0 | OK |

## Réponses complètes (scénarios en échec uniquement)

### rag-02

**Prompt :** Quels modèles de fondation Smartovate utilise-t-elle pour ses projets d'IA générative ?

**Réponse obtenue :** Je vais consulter la base de connaissances interne de Smartovate pour répondre à cette question.La base de connaissances interne de Smartovate ne contient pas de document pertinent sur ce sujet pour le moment.

Pour obtenir une réponse précise sur les modèles de fondation utilisés par Smartovate dans ses projets d'IA générative, je vous recommande :

1. **Consulter l'équipe technique ou le département IA** de Smartovate directement, car cette information peut être confidentielle ou non encore documentée dans la base de connaissances.
2. **Vérifier la documentation interne** (wikis, Confluence, SharePoint, etc.) qui n'est peut-être pas encore indexée dans la base de connaissances.
3. **Contacter votre responsable ou chef de projet** pour obtenir la liste officielle des modèles approuvés.

Si vous avez des fichiers ou documents internes à ce sujet, vous pouvez les charger ici et je les analyserai pour vous. 📄

**Raisons de l'échec :** Aucun mot-clé de ['bedrock', 'claude', 'titan'] trouvé dans la réponse.
