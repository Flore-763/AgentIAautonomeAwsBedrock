# Rapport d'évaluation — Agent IA Autonome

Généré le 2026-08-25 14:12 UTC — 23 scénarios exécutés.

## Résumé global

- **Taux de succès** : 95.7% (22/23)
- **Latence moyenne** : 7.69 s
- **Latence médiane** : 7.46 s
- **Latence P95** : 11.66 s
- **Latence max** : 14.65 s

### Métriques SSE

- **TTFT moyen** : 3.16 s
- **TTFT médian** : 2.88 s
- **TTFT P95** : 4.49 s
- **Chunks SSE moyens** : 61.6
- **Débit moyen** : 7.43 chunks/s
## Détail par catégorie

| Catégorie | Succès | Total | Taux | Latence moy. |
|---|---|---|---|---|
| calculator | 4 | 4 | 100.0% | 7.15 s |
| culture_generale | 2 | 2 | 100.0% | 4.94 s |
| memoire | 2 | 2 | 100.0% | 4.3 s |
| multi_outils | 2 | 2 | 100.0% | 10.27 s |
| prompt_systeme | 4 | 4 | 100.0% | 7.85 s |
| rag_interne | 2 | 3 | 66.7% | 9.87 s |
| robustesse | 2 | 2 | 100.0% | 5.11 s |
| weather | 2 | 2 | 100.0% | 7.04 s |
| web_search | 2 | 2 | 100.0% | 11.99 s |

## Détail par scénario

| ID | Catégorie | Succès | Latence (s) | TTFT (s) | Chunks | Chunks/s | Outils | Raisons |
|---|---|---|---:|---:|---:|---:|---:|---|
| gk-01 | culture_generale | ✅ | 5.71 | 3.64 | 25 | 4.38 | 0 | OK |
| gk-02 | culture_generale | ✅ | 4.17 | 2.68 | 22 | 5.27 | 0 | OK |
| calc-01 | calculator | ✅ | 7.46 | 5.52 | 6 | 0.80 | 1 | OK |
| calc-02 | calculator | ✅ | 6.77 | 3.33 | 22 | 3.25 | 1 | OK |
| calc-03 | calculator | ✅ | 6.65 | 2.92 | 40 | 6.01 | 1 | OK |
| calc-04-edge | calculator | ✅ | 7.70 | 4.60 | 42 | 5.46 | 1 | OK |
| weather-01 | weather | ✅ | 7.45 | 3.08 | 28 | 3.76 | 1 | OK |
| weather-02-edge | weather | ✅ | 6.64 | 2.54 | 33 | 4.97 | 1 | OK |
| web-01 | web_search | ✅ | 9.33 | 4.49 | 88 | 9.43 | 1 | OK |
| web-02 | web_search | ✅ | 14.65 | 3.07 | 183 | 12.49 | 1 | OK |
| rag-01 | rag_interne | ✅ | 11.66 | 2.85 | 144 | 12.35 | 1 | OK |
| rag-02 | rag_interne | ❌ | 8.84 | 3.07 | 85 | 9.62 | 1 | Aucun mot-clé de ['bedrock', 'claude', 'titan'] trouvé dans la réponse. |
| rag-03 | rag_interne | ✅ | 9.11 | 2.58 | 102 | 11.20 | 1 | OK |
| multi-01 | multi_outils | ✅ | 8.67 | 2.87 | 37 | 4.27 | 1 | OK |
| multi-02 | multi_outils | ✅ | 11.87 | 2.66 | 94 | 7.92 | 2 | OK |
| mem-01a | memoire | ✅ | 5.12 | 2.25 | 40 | 7.82 | 0 | OK |
| mem-01b | memoire | ✅ | 3.49 | 2.86 | 10 | 2.87 | 0 | OK |
| hors-sujet-01 | prompt_systeme | ✅ | 9.90 | 3.68 | 77 | 7.78 | 0 | OK |
| hors-sujet-02-religion | prompt_systeme | ✅ | 9.08 | 2.43 | 121 | 13.32 | 0 | OK |
| humour-creatif | prompt_systeme | ✅ | 6.69 | 2.90 | 68 | 10.17 | 0 | OK |
| clarification-01 | prompt_systeme | ✅ | 5.73 | 2.76 | 48 | 8.38 | 0 | OK |
| robustesse-01-message-vide | robustesse | ✅ | 1.76 | - | 0 | - | 0 | Message is required; Rejet propre obtenu, comme attendu. |
| robustesse-02-injection-calcul | robustesse | ✅ | 8.47 | 2.84 | 102 | 12.05 | 0 | OK |

## Réponses complètes (scénarios en échec uniquement)

### rag-02

**Prompt :** Quels modèles de fondation Smartovate utilise-t-elle pour ses projets d'IA générative ?

**Réponse obtenue :** Je vais interroger la base de connaissances interne de Smartovate Ltd pour répondre à cette question.La recherche dans la base de connaissances interne n'a retourné aucun résultat pertinent sur ce sujet.

Je n'ai donc pas d'information documentée concernant les modèles de fondation spécifiquement utilisés par Smartovate Ltd pour ses projets d'IA générative.

Je vous recommande de :
- **Consulter directement l'équipe technique ou le département IA** de Smartovate pour obtenir cette information précise.
- **Vérifier la documentation interne** (wikis, confluence, portails internes) qui pourrait ne pas encore être indexée dans la base de connaissances.

Si vous disposez de documents internes à ce sujet, vous pouvez les **uploader** ici et je les analyserai pour vous fournir une réponse précise. 📂

**Raisons de l'échec :** Aucun mot-clé de ['bedrock', 'claude', 'titan'] trouvé dans la réponse.
